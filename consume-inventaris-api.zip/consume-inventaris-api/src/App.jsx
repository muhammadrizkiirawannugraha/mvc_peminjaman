import React from "react";
import Navbar from "./components/Navbar";

const App = () => {
  return (
    <>
      <Navbar />
      <div className="bg-gray-900 flex flex-col items-center justify-center min-h-screen">
        <div className="bg-gray-800 border-t border-gray-600 shadow rounded-lg max-w-lg w-full p-6 mb-4">
          <h4 className="text-white text-2xl">
            SELAMAT DATANG DI WEBSITE INVETARIS
          </h4>
          <p className="text-lg text-gray-400 leading-relaxed">
            Selamat datang di situs web inventaris kami! Kelola dan pantau semua
            barang serta aset Anda dengan mudah dan efisien menggunakan alat
            canggih kami. Tingkatkan efisiensi bisnis Anda dengan layanan kami
            yang terpercaya.
          </p>
        </div>
        <br />
        <div className="bg-gray-800 border-t border-gray-600 shadow rounded-lg max-w-lg w-full p-6">
          <h4 className="text-white text-2xl">
            Tentang Sistem Inventaris Kami
          </h4>
          <p className="text-lg text-gray-400 leading-relaxed">
            Sistem kami membantu Anda melacak tingkat stok, mengelola aset, dan
            memastikan semua inventaris tercatat dengan akurat dan efisien.
          </p>
        </div>
        <br />
        <div className="bg-gray-800 border-t border-gray-600 shadow rounded-lg max-w-lg w-full p-8">
          <h4 className="text-white text-2xl">Layanan Inventaris Kami</h4>
          <p className="text-lg text-gray-400 leading-relaxed">
            -Pantau tingkat stok Anda secara real-time.
          </p>
          <p className="text-lg text-gray-400 leading-relaxed">
            -Lacak pesanan Anda dari penempatan hingga pengiriman.
          </p>
        </div>
        <p className="text-lg text-gray-400 leading-relaxed">
        </p>
        <br />

        <div className="bg-gray-800 border-t border-gray-600 shadow rounded-lg max-w-lg w-full p-6">
          <h4 className="text-white text-2xl">HUBUNGI SAYA</h4>
          <p className="text-lg text-gray-400 leading-relaxed">
            muhammadrizkiirawannugraha@smkwikrama.sch.id.
          </p>
        </div>
      </div>
    </>
  );
};

export default App;

// function App()
//   const [count, setCount] = useState(0)

//   return (
//     <>
//       <div>
//         <a href="https://vitejs.dev" target="_blank">
//           <img src={viteLogo} className="logo" alt="Vite logo" />
//         </a>
//         <a href="https://react.dev" target="_blank">
//           <img src={reactLogo} className="logo react" alt="React logo" />
//         </a>
//       </div>
//       <h1>Vite + React</h1>
//       <div className="card">
//         <button onClick={() => setCount((count) => count + 1)}>
//           count is {count}
//         </button>
//         <p>
//           Edit <code>src/App.jsx</code> and save to test HMR
//         </p>
//       </div>
//       <p className="read-the-docs">
//         Click on the Vite and React logos to learn more
//       </p>
//     </>
//   )
// }

// export default App
